
using System;
using NUnit.Framework;

namespace tests
{
	
	
	[TestFixture()]
	public class LinuxLocalDeviceTest
	{
		
		public void TestCase()
		{
		}
	}
}
