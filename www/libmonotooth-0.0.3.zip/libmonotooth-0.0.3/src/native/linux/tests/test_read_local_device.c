#include "../include/includes.h"

int main()
{	
	char* name = "";
	printf("SIZEOF : %d\n", sizeof(inquiry_info));
	return 0;
}
