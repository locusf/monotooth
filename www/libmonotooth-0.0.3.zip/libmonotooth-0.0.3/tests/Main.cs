// project created on 5/6/2007 at 12:10 AM
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using Mono.Unix;
namespace MonoTooth
{
	class MainClass
	{
		public static void Main()
		{
		}
	}
}