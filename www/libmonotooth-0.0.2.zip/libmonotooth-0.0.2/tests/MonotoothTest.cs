using System;

namespace MonoTooth
{
	public class MonotoothTest
	{
		public MonotoothTest()
		{
			//string s = MonoTooth.MarshalAssistant.batostr(MonoTooth.MarshalAssistant.getAddress());
			
		}
	}
}
